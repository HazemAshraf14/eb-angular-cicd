
export const environment = {
  production: false,
  serverEndPoint: "https://align-server.twi-cloud-services.com/api/device"
};
