export const environment = {
  production: true,
  serverEndPoint: "https://align-server.twi-cloud-services.com/api/device"
};
